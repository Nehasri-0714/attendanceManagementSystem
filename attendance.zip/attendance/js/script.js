// Sample JS file
console.log("Attendance Management System script loaded.");